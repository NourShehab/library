package edu.guc.library.config;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories("edu.guc.library.repository")
public class DatabaseConfiguration {
}
